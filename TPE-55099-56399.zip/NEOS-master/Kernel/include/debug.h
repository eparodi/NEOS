#ifndef DEBUG_H
#define DEBUG_H

int
parse_int(char * buffer, long number, int radix);

#endif
