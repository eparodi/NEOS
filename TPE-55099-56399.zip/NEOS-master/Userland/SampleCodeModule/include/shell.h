#ifndef SHELL_H
#define SHELL_H
/*
 * Start the shell.
 */
void start_shell();
#define MAX_SIZE 1000

#endif
