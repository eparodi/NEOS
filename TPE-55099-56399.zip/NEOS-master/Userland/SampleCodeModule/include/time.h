#ifndef TIME_H
#define TIME_H

/*
 *	Returns a String with the actual hour.
 *	Return:
 *		A String with the actual hour.
 */
char *
get_hour();


char *
get_date();

#endif
