
void drawFractal(int x, int y,unsigned int siz);
void drawFractalc(int x, int y,unsigned int siz,unsigned int color);
