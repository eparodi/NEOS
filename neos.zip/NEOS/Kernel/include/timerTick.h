#ifndef TIMERTICK_H
#define TIMERTICK_H
void sleep(int time);
void tick();
#define MAXCOUNTERS 12
#define NOT -1

#endif
