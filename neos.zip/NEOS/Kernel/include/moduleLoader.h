#ifndef MODULELOADER_H
#define MODULELOADER_H

/*
 * Load all modules.
 */
void loadModules(void * payloadStart, void ** moduleTargetAddress);

#endif